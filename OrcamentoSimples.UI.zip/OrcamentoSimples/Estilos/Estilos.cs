﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace OrcamentoSimples.Estilos
{
    public static class Estilos
    {
        public static void AplicarEstiloBotao(Button botao)
        {
            botao.FlatStyle = FlatStyle.Flat;
            botao.FlatAppearance.BorderSize = 0;
            botao.BackColor = ColorTranslator.FromHtml("#00FF9C"); // verde base
            botao.ForeColor = Color.White;
            botao.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            botao.Height = 35;

            botao.Paint += (s, e) =>
            {
                var radius = 8;
                var path = new GraphicsPath();
                path.AddArc(0, 0, radius, radius, 180, 90);
                path.AddArc(botao.Width - radius, 0, radius, radius, 270, 90);
                path.AddArc(botao.Width - radius, botao.Height - radius, radius, radius, 0, 90);
                path.AddArc(0, botao.Height - radius, radius, radius, 90, 90);
                path.CloseFigure();

                botao.Region = new Region(path);
            };
        }

        public static void AplicarEstiloTextBox(TextBox txt)
        {
            txt.BorderStyle = BorderStyle.None;
            txt.BackColor = ColorTranslator.FromHtml("#CCFFE9"); // tom bem claro
            txt.Font = new Font("Segoe UI", 9F);
            txt.Padding = new Padding(8);
        }

        // Se quiser criar painéis com borda e canto arredondado futuramente:
        public static GraphicsPath ArredondarRetangulo(Rectangle bounds, int raio)
        {
            var path = new GraphicsPath();
            path.AddArc(bounds.Left, bounds.Top, raio, raio, 180, 90);
            path.AddArc(bounds.Right - raio, bounds.Top, raio, raio, 270, 90);
            path.AddArc(bounds.Right - raio, bounds.Bottom - raio, raio, raio, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - raio, raio, raio, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
