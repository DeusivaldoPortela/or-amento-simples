﻿using System.Drawing;

namespace OrcamentoSimples.Tema
{
    public static class AppTheme
    {
        public static bool IsDarkMode { get; set; } = false;

        public static Color PrimaryColor => Color.FromArgb(0, 255, 156);
        public static Color PrimaryHover => Color.FromArgb(0, 230, 140);

        public static Color BackgroundLight => Color.White;
        public static Color ForegroundLight => Color.Black;

        public static Color BackgroundDark => Color.FromArgb(40, 40, 40);
        public static Color ForegroundDark => Color.WhiteSmoke;

        public static Color BorderColor => IsDarkMode ? Color.Gray : PrimaryColor;
        public static Color BorderFocusColor => IsDarkMode ? Color.FromArgb(100, 100, 100) : PrimaryHover;
        public static Color PlaceholderColor => IsDarkMode ? Color.DarkGray : Color.Gray;
    }
}
