﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace OrcamentoSimples.Helpers
{
    public static class EstiloHelper
    {
        public static void AplicarEstiloBotao(Button botao)
        {
            botao.FlatStyle = FlatStyle.Flat;
            botao.FlatAppearance.BorderSize = 0;
            botao.BackColor = ColorTranslator.FromHtml("#00FF9C");
            botao.ForeColor = Color.White;
            botao.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            botao.Height = 35;

            var corNormal = ColorTranslator.FromHtml("#00FF9C");
            var corHover = ColorTranslator.FromHtml("#00D68C");

            botao.MouseEnter += (s, e) => botao.BackColor = corHover;
            botao.MouseLeave += (s, e) => botao.BackColor = corNormal;

            botao.Paint += (s, e) =>
            {
                int radius = 8;
                var path = new GraphicsPath();
                path.AddArc(0, 0, radius, radius, 180, 90);
                path.AddArc(botao.Width - radius, 0, radius, radius, 270, 90);
                path.AddArc(botao.Width - radius, botao.Height - radius, radius, radius, 0, 90);
                path.AddArc(0, botao.Height - radius, radius, radius, 90, 90);
                path.CloseFigure();

                botao.Region = new Region(path);
            };
        }
    }
}
