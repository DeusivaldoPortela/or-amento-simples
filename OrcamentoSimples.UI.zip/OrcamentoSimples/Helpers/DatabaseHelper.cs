﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;

namespace OrcamentoSimples.Helpers
{
    public class Movimento
    {
        public string Tipo { get; set; }
        public string Descricao { get; set; }
        public decimal Valor { get; set; }
    }

    public static class DatabaseHelper
    {
        private static string dbFile = "orcamento.db";
        private static string connectionString = $"Data Source={dbFile};Version=3;";

        public static void Inicializar()
        {
            if (!File.Exists(dbFile))
            {
                SQLiteConnection.CreateFile(dbFile);
            }

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = @"
                    CREATE TABLE IF NOT EXISTS Movimentos (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Tipo TEXT NOT NULL,
                        Descricao TEXT NOT NULL,
                        Valor REAL NOT NULL
                    );";

                using (var command = new SQLiteCommand(sql, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        public static void AdicionarMovimento(Movimento mov)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "INSERT INTO Movimentos (Tipo, Descricao, Valor) VALUES (@tipo, @descricao, @valor)";
                using (var cmd = new SQLiteCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@tipo", mov.Tipo);
                    cmd.Parameters.AddWithValue("@descricao", mov.Descricao);
                    cmd.Parameters.AddWithValue("@valor", mov.Valor);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public static void EditarMovimento(int id, Movimento mov)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "UPDATE Movimentos SET Tipo = @tipo, Descricao = @descricao, Valor = @valor WHERE Id = @id";
                using (var cmd = new SQLiteCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@tipo", mov.Tipo);
                    cmd.Parameters.AddWithValue("@descricao", mov.Descricao);
                    cmd.Parameters.AddWithValue("@valor", mov.Valor);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void RemoverMovimento(int id)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "DELETE FROM Movimentos WHERE Id = @id";
                using (var cmd = new SQLiteCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static List<(int Id, Movimento Mov)> ObterTodos()
        {
            var lista = new List<(int, Movimento)>();

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "SELECT Id, Tipo, Descricao, Valor FROM Movimentos";
                using (var cmd = new SQLiteCommand(sql, connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var id = reader.GetInt32(0);
                        var mov = new Movimento
                        {
                            Tipo = reader.GetString(1),
                            Descricao = reader.GetString(2),
                            Valor = (decimal)reader.GetDouble(3)
                        };
                        lista.Add((id, mov));
                    }
                }
            }

            return lista;
        }




        public static decimal ObterSaldo()
        {
            decimal saldo = 0;

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "SELECT Tipo, Valor FROM Movimentos";
                using (var cmd = new SQLiteCommand(sql, connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string tipo = reader.GetString(0);
                        decimal valor = (decimal)reader.GetDouble(1);
                        saldo += tipo == "Receita" ? valor : -valor;
                    }
                }
            }

            return saldo;
        }
        public static void LimparBanco()
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "DELETE FROM Movimentos";
                using (var cmd = new SQLiteCommand(sql, connection))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }


    }
}
