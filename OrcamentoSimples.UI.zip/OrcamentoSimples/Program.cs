using OrcamentoSimples.Helpers;

namespace OrcamentoSimples
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
      
            [STAThread]
            static void Main()
            {
                // Inicializa o banco de dados antes de abrir o app
                DatabaseHelper.Inicializar();

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1());
            }
        
    }
}