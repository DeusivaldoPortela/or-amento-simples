﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using OrcamentoSimples.Tema;

namespace OrcamentoSimples.Controles
{
    [ToolboxBitmap(typeof(DataGridView))]
    public class DataGridPersonalizado : DataGridView
    {
        public DataGridPersonalizado()
        {
            // Geral
            this.EnableHeadersVisualStyles = false;
            this.RowHeadersVisible = false;
            this.AllowUserToAddRows = false;
            this.AllowUserToResizeRows = false;
            this.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.MultiSelect = false;
            this.ReadOnly = true;
            this.BorderStyle = BorderStyle.None;
            this.Font = new Font("Segoe UI", 10);

            this.BackColor = CoresApp.FundoPrincipal;
            this.DefaultCellStyle.BackColor =CoresApp.FundoPrincipal;
            this.DefaultCellStyle.ForeColor = AppTheme.IsDarkMode ? AppTheme.ForegroundDark : AppTheme.ForegroundLight;
            this.DefaultCellStyle.SelectionBackColor = Color.FromArgb(200, 255, 200);
            this.DefaultCellStyle.SelectionForeColor = Color.Black; 

            // Cabeçalho
            this.ColumnHeadersDefaultCellStyle.BackColor = AppTheme.PrimaryColor;
            this.ColumnHeadersDefaultCellStyle.ForeColor = CoresApp.FundoTopo;
            this.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            this.ColumnHeadersHeight = 35;

            // Linhas alternadas
            this.AlternatingRowsDefaultCellStyle.BackColor =CoresApp.FundoTopo; 
        }
        public static class CoresApp
        {
            public static Color FundoPrincipal => Color.WhiteSmoke;
            public static Color FundoTopo => Color.FromArgb(245, 245, 245);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            this.BackgroundColor = AppTheme.IsDarkMode ? AppTheme.BackgroundDark : AppTheme.BackgroundLight;
        }
    }
}
