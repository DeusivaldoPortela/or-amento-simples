﻿using OrcamentoSimples.Tema;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Topshelf.Runtime.Windows;

namespace OrcamentoSimples.Controles
{
    public class DialogMensagem : Form
    {
        private Label lblTitulo;
        private Label lblMensagem;
        private PictureBox picIcone;
        private Button btnConfirmar;
        private Panel painelTopo;
        private Button btnFechar;

        // WinAPI para arrastar o formulário sem borda
        [DllImport("user32.dll")] private static extern bool ReleaseCapture();
        [DllImport("user32.dll")] private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;

        public DialogMensagem(string titulo, string mensagem, TipoDialogo tipo = TipoDialogo.Informacao)
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(360, 160);
            BackColor = AppTheme.BackgroundLight;
            TopMost = true;
            DoubleBuffered = true;
        
            CriarPainelTopo(titulo);
            CriarIcone(tipo);
            CriarMensagem(mensagem);
            CriarBotao();

            Controls.AddRange(new Control[] { painelTopo, picIcone, lblMensagem, btnConfirmar });

            // Arredondar bordas
            this.Load += (s, e) =>
            {
                this.Region = Region.FromHrgn(NativeMethods.CreateRoundRectRgn(0, 0, Width, Height, 10, 10));

            };
        }
        internal static class NativeMethods
        {
            [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
            public static extern IntPtr CreateRoundRectRgn(
                int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
                int nWidthEllipse, int nHeightEllipse);
        }

        private void CriarPainelTopo(string titulo)
        {
            painelTopo = new Panel
            {
                Size = new Size(this.Width, 30),
                Location = new Point(0, 0),
                BackColor = AppTheme.PrimaryColor
            };

            painelTopo.MouseDown += (s, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    ReleaseCapture();
                    SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
                }
            };

            lblTitulo = new Label
            {
                Text = titulo,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(10, 5),
                AutoSize = true
            };

            btnFechar = new Button
            {
                Text = "X",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                BackColor = Color.Transparent,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(25, 25),
                Dock = DockStyle.Right,
                Cursor = Cursors.Hand
            };
            btnFechar.FlatAppearance.BorderSize = 0;
            btnFechar.Click += (s, e) => this.Close();

            painelTopo.Controls.Add(lblTitulo);
            painelTopo.Controls.Add(btnFechar);
        }

        private void CriarIcone(TipoDialogo tipo)
        {
            picIcone = new PictureBox
            {
                Size = new Size(42, 42),
                Location = new Point(20, 55),
                SizeMode = PictureBoxSizeMode.StretchImage
            };

            picIcone.Image = tipo switch
            {
                TipoDialogo.Sucesso => SystemIcons.Information.ToBitmap(),
                TipoDialogo.Erro => SystemIcons.Error.ToBitmap(),
                TipoDialogo.Alerta => SystemIcons.Warning.ToBitmap(),
                _ => SystemIcons.Information.ToBitmap()
            };
        }

        private void CriarMensagem(string mensagem)
        {
            lblMensagem = new Label
            {
                Text = mensagem,
                Font = new Font("Segoe UI", 9.5F),
                ForeColor = AppTheme.ForegroundLight,
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleLeft,
                Location = new Point(75, 55),
                Size = new Size(260, 50)
            };
        }

        private void CriarBotao()
        {
            btnConfirmar = new Button
            {
                Text = "OK",
                DialogResult = DialogResult.OK,
                Width = 90,
                Height = 30,
                BackColor = AppTheme.PrimaryColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Location = new Point((this.Width - 90) / 2, 110)
            };
            btnConfirmar.FlatAppearance.BorderSize = 0;
            btnConfirmar.Click += (s, e) => this.Close();
        }

        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
        {
            int d = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        // Métodos utilitários
        public static void MostrarCamposObrigatorios()
        {
            Mostrar("Campos obrigatórios", "Por favor, preencha todos os campos.", TipoDialogo.Alerta);
        }

        public static void MostrarValorInvalido()
        {
            Mostrar("Valor inválido", "Digite um valor numérico válido.", TipoDialogo.Erro);
        }

        public static void Mostrar(string titulo, string mensagem, TipoDialogo tipo = TipoDialogo.Informacao)
        {
            using var dlg = new DialogMensagem(titulo, mensagem, tipo);
            dlg.ShowDialog();
        }
    }

    public enum TipoDialogo
    {
        Informacao,
        Sucesso,
        Erro,
        Alerta
    }
}
