﻿using OrcamentoSimples.Tema;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace OrcamentoSimples.Controles
{
    [ToolboxBitmap(typeof(Label))]
    public class LabelPersonalizada : Label
    {
        public LabelPersonalizada()
        {
            this.AutoSize = false;
            this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            this.TextAlign = ContentAlignment.MiddleLeft;
            this.Size = new Size(120, 25);

            ApplyTheme();
        }

        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            ApplyTheme();
        }

        protected override void OnForeColorChanged(EventArgs e)
        {
            base.OnForeColorChanged(e);
            ApplyTheme(); 
        }

        private void ApplyTheme()
        {
            this.ForeColor = AppTheme.IsDarkMode ? AppTheme.ForegroundDark : AppTheme.ForegroundLight;
            this.BackColor = Color.Transparent;
        }
    }
}
