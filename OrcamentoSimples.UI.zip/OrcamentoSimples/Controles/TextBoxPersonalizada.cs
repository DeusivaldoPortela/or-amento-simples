﻿using OrcamentoSimples.Tema;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace OrcamentoSimples.Controles
{
    [ToolboxBitmap(typeof(TextBoxPersonalizada))]
    public class TextBoxPersonalizada : UserControl
    {
        private readonly TextBox innerTextBox = new();
        private readonly Label placeholderLabel = new();

        private string placeholderText = "Digite aqui...";
        private int borderRadius = 6;

        public TextBoxPersonalizada()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.UserPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw, true);

            DoubleBuffered = true;
            Cursor = Cursors.IBeam;
            Padding = new Padding(8);
            MinimumSize = new Size(100, 35);
            Size = new Size(200, 25);
            BackColor = Color.Transparent;

            innerTextBox.BorderStyle = BorderStyle.None;
            innerTextBox.Font = new Font("Segoe UI", 10);
            innerTextBox.Multiline = false;
            innerTextBox.Location = new Point(Padding.Left, Padding.Top);
            innerTextBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;

            innerTextBox.Enter += (s, e) => { Invalidate(); UpdatePlaceholderVisibility(); };
            innerTextBox.Leave += (s, e) => { Invalidate(); UpdatePlaceholderVisibility(); };
            innerTextBox.TextChanged += (s, e) => { UpdatePlaceholderVisibility(); Invalidate(); };
            innerTextBox.KeyDown += InnerTextBox_KeyDown;

            placeholderLabel.Text = placeholderText;
            placeholderLabel.Font = innerTextBox.Font;
            placeholderLabel.BackColor = Color.Transparent;
            placeholderLabel.AutoSize = false;
            placeholderLabel.TextAlign = ContentAlignment.MiddleLeft;
            placeholderLabel.Click += (s, e) => innerTextBox.Focus();

            Controls.Add(placeholderLabel);
            Controls.Add(innerTextBox);

            this.HandleCreated += (s, e) => ApplyTheme(); // <- Garante tema ao carregar
            UpdateLayout();
        }

        // ---- Propriedades públicas ----

        [Category("Aparência")]
        public string PlaceholderText
        {
            get => placeholderText;
            set
            {
                placeholderText = value;
                placeholderLabel.Text = value;
                Invalidate();
            }
        }

        [Category("Aparência")]
        public override string Text
        {
            get => innerTextBox.Text;
            set
            {
                innerTextBox.Text = value;
                UpdatePlaceholderVisibility();
                Invalidate();
            }
        }

        [Category("Aparência")]
        public int BorderRadius
        {
            get => borderRadius;
            set
            {
                borderRadius = Math.Max(0, value);
                Invalidate();
            }
        }

        public string TextBoxText
        {
            get => innerTextBox.Text;
            set => innerTextBox.Text = value;
        }

        public TextBox CaixaInterna => innerTextBox;

        // ---- Métodos privados ----

        private void ApplyTheme()
        {
            innerTextBox.BackColor = AppTheme.IsDarkMode ? AppTheme.BackgroundDark : AppTheme.BackgroundLight;
            innerTextBox.ForeColor = AppTheme.IsDarkMode ? AppTheme.ForegroundDark : AppTheme.ForegroundLight;
            placeholderLabel.ForeColor = AppTheme.PlaceholderColor;
            Invalidate();
        }

        private void UpdatePlaceholderVisibility()
        {
            placeholderLabel.Visible = string.IsNullOrWhiteSpace(innerTextBox.Text) && !innerTextBox.Focused;
        }

        private void InnerTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                this.Parent?.SelectNextControl(this, true, true, true, true);
            }
        }

        private void UpdateLayout()
        {
            innerTextBox.Size = new Size(Width - Padding.Horizontal, Height - Padding.Vertical);
            innerTextBox.Location = new Point(Padding.Left, Padding.Top);

            placeholderLabel.Size = innerTextBox.Size;
            placeholderLabel.Location = innerTextBox.Location;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            UpdateLayout();
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            Rectangle rect = new(0, 0, Width - 1, Height - 1);
            Color border = innerTextBox.Focused ? AppTheme.BorderFocusColor : AppTheme.BorderColor;

            using GraphicsPath path = GetRoundedPath(rect, borderRadius);
            using Pen pen = new(border, 1);
            using SolidBrush brush = new(innerTextBox.BackColor);

            e.Graphics.FillPath(brush, path);
            e.Graphics.DrawPath(pen, path);
        }

        private GraphicsPath GetRoundedPath(Rectangle rect, int radius)
        {
            int d = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
