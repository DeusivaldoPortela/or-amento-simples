﻿using OrcamentoSimples.Tema;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace OrcamentoSimples.Controles
{
    [ToolboxBitmap(typeof(Label))]
    public class TituloSecao : Label
    {
        public TituloSecao()
        {
            this.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            this.AutoSize = false;
            this.Height = 40;
            this.TextAlign = ContentAlignment.MiddleLeft;

            ApplyTheme();
        }

        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            ApplyTheme();
        }

        private void ApplyTheme()
        {
            this.ForeColor = AppTheme.IsDarkMode ? AppTheme.ForegroundDark : AppTheme.PrimaryColor;
            this.BackColor = Color.Transparent;
        }
    }
}
