﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace OrcamentoSimples.Controles
{
    [ToolboxBitmap(typeof(ComboBoxPersonalizado))]
    public class ComboBoxPersonalizado : ComboBox
    {
        private bool isDarkMode = false;

        private Color lightBackColor = Color.White;
        private Color lightForeColor = Color.Black;
        private Color darkBackColor = Color.FromArgb(40, 40, 40);
        private Color darkForeColor = Color.WhiteSmoke;

        private Color lightBorderColor = Color.FromArgb(0, 255, 156);     
        private Color darkBorderColor = Color.Gray;

        public ComboBoxPersonalizado()
        {
            DrawMode = DrawMode.OwnerDrawFixed;
            DropDownStyle = ComboBoxStyle.DropDownList;
            FlatStyle = FlatStyle.Flat;
            Font = new Font("Segoe UI", 10F);
            ItemHeight = 30;

            ApplyTheme();
        }

        [Category("Aparência")]
        public bool IsDarkMode
        {
            get => isDarkMode;
            set
            {
                isDarkMode = value;
                ApplyTheme();
                Invalidate();
            }
        }

        [Category("Cores Personalizadas")]
        public Color LightBorderColor
        {
            get => lightBorderColor;
            set { lightBorderColor = value; Invalidate(); }
        }

        [Category("Cores Personalizadas")]
        public Color DarkBorderColor
        {
            get => darkBorderColor;
            set { darkBorderColor = value; Invalidate(); }
        }

        private void ApplyTheme()
        {
            BackColor = isDarkMode ? darkBackColor : lightBackColor;
            ForeColor = isDarkMode ? darkForeColor : lightForeColor;
        }

        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            e.DrawBackground();

            if (e.Index >= 0)
            {
                string text = Items[e.Index].ToString();
                bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;

                Color bgColor = selected
                    ? (isDarkMode ? Color.FromArgb(60, 60, 60) : Color.FromArgb(230, 255, 245))
                    : this.BackColor;

                using var bgBrush = new SolidBrush(bgColor);
                using var textBrush = new SolidBrush(this.ForeColor);

                e.Graphics.FillRectangle(bgBrush, e.Bounds);
                e.Graphics.DrawString(text, this.Font, textBrush, e.Bounds.X + 5, e.Bounds.Y + 4);
            }

            e.DrawFocusRectangle();
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);

            // Redesenha borda após o controle ser pintado
            if (m.Msg == 0xF) 
            {
                using Graphics g = Graphics.FromHwnd(this.Handle);
                Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
                Color borderColor = isDarkMode ? darkBorderColor : lightBorderColor;

                using Pen borderPen = new Pen(borderColor, 1.5f);
                g.DrawRectangle(borderPen, rect);
            }
        }
    }
}
