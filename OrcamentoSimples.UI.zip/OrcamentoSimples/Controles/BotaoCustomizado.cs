﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace OrcamentoSimples.Controles
{
    public class BotaoCustomizado : Button
    {
        private int borderRadius = 8; 
        private bool _mouseOver = false;

        public BotaoCustomizado()
        {
            this.FlatStyle = FlatStyle.Flat;
            this.FlatAppearance.BorderSize = 0;
            this.BackColor = _lightBackColor;
            this.ForeColor = Color.White;
            this.Cursor = Cursors.Hand;
            this.MinimumSize = new Size(100, 30);
            this.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            this.DoubleBuffered = true;
        }

        [Category("Design")]
        public int BorderRadius
        {
            get => borderRadius;
            set
            {
                borderRadius = Math.Max(0, value);
                this.Invalidate();
            }
        }

        private bool _isDarkMode = false;
        [Category("Appearance")]
        public bool IsDarkMode
        {
            get => _isDarkMode;
            set
            {
                _isDarkMode = value;
                this.BackColor = value ? _darkBackColor : _lightBackColor;
                this.Invalidate();
            }
        }

        private Color _lightBackColor = Color.FromArgb(0, 255, 156); 
        [Category("Appearance")]
        public Color LightBackColor
        {
            get => _lightBackColor;
            set
            {
                _lightBackColor = value;
                if (!_isDarkMode && !_mouseOver)
                    this.BackColor = value;
            }
        }

        private Color _darkBackColor = Color.FromArgb(20, 20, 20);
        [Category("Appearance")]
        public Color DarkBackColor
        {
            get => _darkBackColor;
            set
            {
                _darkBackColor = value;
                if (_isDarkMode && !_mouseOver)
                    this.BackColor = value;
            }
        }

        private Color _lightHoverColor = Color.FromArgb(0, 230, 140); 
        [Category("Appearance")]
        public Color LightHoverColor
        {
            get => _lightHoverColor;
            set => _lightHoverColor = value;
        }

        private Color _darkHoverColor = Color.FromArgb(60, 60, 60);
        [Category("Appearance")]
        public Color DarkHoverColor
        {
            get => _darkHoverColor;
            set => _darkHoverColor = value;
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            _mouseOver = true;
            this.BackColor = _isDarkMode ? _darkHoverColor : _lightHoverColor;
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            _mouseOver = false;
            this.BackColor = _isDarkMode ? _darkBackColor : _lightBackColor;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rectSurface = this.ClientRectangle;

            using (GraphicsPath pathSurface = GetFigurePath(rectSurface, borderRadius))
            using (SolidBrush brushSurface = new SolidBrush(this.BackColor))
            using (Pen penSurface = new Pen(this.Parent?.BackColor ?? Color.White, 1))
            {
                this.Region = new Region(pathSurface);
                e.Graphics.FillPath(brushSurface, pathSurface);
                e.Graphics.DrawPath(penSurface, pathSurface);

                TextRenderer.DrawText(
                    e.Graphics,
                    this.Text,
                    this.Font,
                    rectSurface,
                    this.ForeColor,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter
                );
            }
        }

        private GraphicsPath GetFigurePath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            float curveSize = radius * 2F;

            path.StartFigure();
            path.AddArc(rect.X, rect.Y, curveSize, curveSize, 180, 90);
            path.AddArc(rect.Right - curveSize, rect.Y, curveSize, curveSize, 270, 90);
            path.AddArc(rect.Right - curveSize, rect.Bottom - curveSize, curveSize, curveSize, 0, 90);
            path.AddArc(rect.X, rect.Bottom - curveSize, curveSize, curveSize, 90, 90);
            path.CloseFigure();

            return path;
        }
    }
}
