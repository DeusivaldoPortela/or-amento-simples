﻿using OrcamentoSimples.Tema;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace OrcamentoSimples.Controles
{
    public class MenuButton : Button
    {
        private bool _isSelected = false;

        public MenuButton()
        {
            this.FlatStyle = FlatStyle.Flat;
            this.FlatAppearance.BorderSize = 0;
            this.TextAlign = ContentAlignment.MiddleLeft;
            this.Padding = new Padding(12, 0, 0, 0);
            this.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.ForeColor = Color.White;
            this.Height = 40;
            this.Dock = DockStyle.Top;
            this.BackColor = Color.FromArgb(60, 60, 60);
        }

        [Category("Comportamento")]
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                AtualizarCor();
            }
        }

        private void AtualizarCor()
        {
            if (_isSelected)
                this.BackColor = AppTheme.PrimaryColor;
            else
                this.BackColor = Color.FromArgb(60, 60, 60);
        }
    }
}
