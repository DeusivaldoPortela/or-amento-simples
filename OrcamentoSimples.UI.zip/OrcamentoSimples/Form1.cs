using OrcamentoSimples.Controles;
using OrcamentoSimples.Telas;
using System.Drawing;
using System.Windows.Forms;

namespace OrcamentoSimples
{
    public partial class Form1 : Form
    {
        private Panel painelCentral;
        private Panel painelMenu;
        private MenuButton botaoSelecionado;

        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(245, 245, 245);
            InicializarLayout();
        }

        private void InicializarLayout()
        {
            this.Text = "Or�amento Simples";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
          
            // PAINEL DE MENU
            painelMenu = new Panel
            {
                Dock = DockStyle.Left,
                Width = 180,
                BackColor = Color.FromArgb(40, 40, 40)
            };

            // PAINEL DE CONTE�DO
            painelCentral = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.WhiteSmoke,

                Padding = new Padding(20)
            };

            // Adiciona bot�es de menu
            painelMenu.Controls.Add(CriarBotaoMenu("Cadastrar", () => CarregarTela(new TelaCadastro())));
            painelMenu.Controls.Add(CriarBotaoMenu("Listar Movimentos", () => CarregarTela(new TelaLista())));
            painelMenu.Controls.Add(CriarBotaoMenu("Resumo", () => CarregarTela(new TelaResumo())));
            painelMenu.Controls.Add(CriarBotaoMenu("Filtros", () => CarregarTela(new TelaFiltros())));
            painelMenu.Controls.Add(CriarBotaoMenu("Limpar Dados", () => CarregarTela(new TelaLimparDados())));
            painelMenu.Controls.Add(CriarBotaoMenu("Sobre", () => CarregarTela(new TelaSobre())));

            Controls.Add(painelCentral);
            Controls.Add(painelMenu);

            // Carrega a primeira tela e marca como selecionado
            if (painelMenu.Controls[0] is MenuButton primeiroBotao)
                primeiroBotao.PerformClick();
        }

        private MenuButton CriarBotaoMenu(string texto, System.Action onClick)
        {
            var btn = new MenuButton
            {
                Text = texto,
            };

            btn.Click += (s, e) =>
            {
                DefinirSelecionado(btn);
                onClick?.Invoke();
            };

            return btn;
        }

        private void DefinirSelecionado(MenuButton selecionado)
        {
            if (botaoSelecionado != null)
                botaoSelecionado.IsSelected = false;

            botaoSelecionado = selecionado;
            botaoSelecionado.IsSelected = true;
        }

        private void CarregarTela(UserControl tela)
        {
            painelCentral.Controls.Clear();
            painelCentral.Controls.Add(tela);
        }
    }
}
