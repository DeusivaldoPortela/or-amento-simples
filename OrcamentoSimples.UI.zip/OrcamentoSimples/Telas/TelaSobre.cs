﻿using OrcamentoSimples.Controles;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace OrcamentoSimples.Telas
{
    public partial class TelaSobre : UserControl
    {
        public TelaSobre()
        {
            InitializeComponent();
            CriarLayout();
        }


        //criação do layout do sistema
        private void CriarLayout()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.WhiteSmoke;

            var titulo = new Label
            {
                Text = "Orçamento Simples",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 150, 100),
                Location = new Point(30, 30),
                AutoSize = true
            };

            var versao = new Label
            {
                Text = "Versão: 1.0.0",
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.Gray,
                Location = new Point(30, 70),
                AutoSize = true
            };

            var lblDescricao = new LabelPersonalizada
            {
                Text = "Aplicativo para controle básico de receitas e despesas.\nConstruído com C#, Windows Forms e SQLite.",
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.DimGray,
                Location = new Point(30, 105),
                MaximumSize = new Size(600, 0),
                AutoSize = true
            };

            var autor = new Label
            {
                Text = "Desenvolvido por: Deusivaldo Portela",
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.Gray,
                Location = new Point(30, lblDescricao.Bottom + 20),
                AutoSize = true
            };

            var linkGithub = new LinkLabel
            {
                Text = "https://github.com/DeusivaldoPortela",
                Font = new Font("Segoe UI", 10F),
                LinkColor = Color.Blue,
                Location = new Point(30, autor.Bottom + 10),
                AutoSize = true
            };
            linkGithub.LinkClicked += (s, e) =>
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = linkGithub.Text,
                    UseShellExecute = true
                });
            };

            var copyright = new Label
            {
                Text = "© 2025 Orçamento Simples",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.DimGray,
                Location = new Point(30, linkGithub.Bottom + 20),
                AutoSize = true
            };

            Controls.AddRange(new Control[] {
                titulo, versao, lblDescricao,
                autor, linkGithub, copyright
            });
        }
    }
}
