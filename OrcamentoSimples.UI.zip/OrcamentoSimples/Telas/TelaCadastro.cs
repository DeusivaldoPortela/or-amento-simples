﻿using OrcamentoSimples.Controles;
using OrcamentoSimples.Helpers;
using System;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Windows.Forms;

namespace OrcamentoSimples.Telas
{
    public partial class TelaCadastro : UserControl
    {
        private Label lblTipo, lblDescricao, lblValor;
        private ComboBox cmbTipo;
        private TextBox txtDescricao, txtValor;
        private BotaoCustomizado btnSalvar;


        //inicio da tela
        public TelaCadastro()
        {
            InitializeComponent();
            CriarControles();
        }


        //criação dos controles
        private void CriarControles()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.WhiteSmoke;

            var painel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20)
            };
            this.Controls.Add(painel);

            lblTipo = CriarLabel("Tipo:");
            cmbTipo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Width = 200,
                Font = new Font("Segoe UI", 10)
            };
            cmbTipo.Items.AddRange(new string[] { "Receita", "Despesa" });
            cmbTipo.SelectedIndex = 0;

            lblDescricao = CriarLabel("Descrição:");
            txtDescricao = CriarTextBox();

            lblValor = CriarLabel("Valor (R$):");
            txtValor = CriarTextBox();

            btnSalvar = new BotaoCustomizado
            {
                Text = "Salvar",
                Width = 100,
                Height = 35,
                BorderRadius = 6,
                LightBackColor = Color.FromArgb(0, 255, 156),
                LightHoverColor = Color.FromArgb(0, 230, 140)
            };
            btnSalvar.Click += BtnSalvar_Click;

            EstiloHelper.AplicarEstiloBotao(btnSalvar);

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                RowCount = 5,
                ColumnCount = 2,
                AutoSize = true,
                Padding = new Padding(10),
                BackColor = Color.Transparent
            };

            layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            layout.Controls.Add(lblTipo, 0, 0);
            layout.Controls.Add(cmbTipo, 1, 0);
            layout.Controls.Add(lblDescricao, 0, 1);
            layout.Controls.Add(txtDescricao, 1, 1);
            layout.Controls.Add(lblValor, 0, 2);
            layout.Controls.Add(txtValor, 1, 2);
            layout.Controls.Add(btnSalvar, 1, 4);

            painel.Controls.Add(layout);
        }


        //botão para salvar os dados
        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtDescricao.Text) || string.IsNullOrWhiteSpace(txtValor.Text))
            {
                DialogMensagem.MostrarCamposObrigatorios();
                return;
            }

            if (!decimal.TryParse(txtValor.Text, out decimal valor))
            {
                DialogMensagem.MostrarValorInvalido();
                return;
            }

            var movimento = new Movimento
            {
                Tipo = cmbTipo.SelectedItem.ToString(),
                Descricao = txtDescricao.Text.Trim(),
                Valor = valor
            };

            DatabaseHelper.AdicionarMovimento(movimento);
            DialogMensagem.Mostrar("Sucesso", "Movimento salvo com sucesso!", TipoDialogo.Sucesso);

            txtDescricao.Clear();
            txtValor.Clear();
            cmbTipo.SelectedIndex = 0;
        }


        //criar as labels principais
        private Label CriarLabel(string texto)
        {
            return new Label
            {
                Text = texto,
                Font = new Font("Segoe UI", 10F, FontStyle.Regular),
                AutoSize = true,
                Anchor = AnchorStyles.Left
            };
        }


        //cria textbox
        private TextBox CriarTextBox()
        {
            return new TextBox
            {
                Width = 200,
                Font = new Font("Segoe UI", 10)
            };
        }
    }
}
