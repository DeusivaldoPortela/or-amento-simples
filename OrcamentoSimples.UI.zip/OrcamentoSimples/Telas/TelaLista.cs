﻿using OrcamentoSimples.Controles;
using OrcamentoSimples.Helpers;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace OrcamentoSimples.Telas
{
    public partial class TelaLista : UserControl
    {
        private DataGridPersonalizado grid; // Correto aqui
        private Button btnExportar;

        public TelaLista()
        {
            InitializeComponent();
            CriarControles();
            CarregarDados();
            this.BackColor = CoresApp.FundoPrincipal;
          

        }

        private void CriarControles()
        {
            this.Size = new Size(900, 600);
            this.AutoScroll = false;
            this.BackColor = CoresApp.FundoPrincipal;

            // Instancia corretamente o grid da classe
            grid = new DataGridPersonalizado
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                BackgroundColor = CoresApp.FundoPrincipal,
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            };


            grid.Columns.Add("Id", "ID");
            grid.Columns.Add("Tipo", "Tipo");
            grid.Columns.Add("Descricao", "Descrição");
            grid.Columns.Add("Valor", "Valor");

            grid.Columns["Id"].Width = 50;
            grid.Columns["Tipo"].Width = 100;
            grid.Columns["Descricao"].Width = 200;
            grid.Columns["Valor"].Width = 100;

            // Botões de ação
            grid.Columns.Add(new DataGridViewButtonColumn
            {
                HeaderText = "Editar",
                Text = "Editar",
                UseColumnTextForButtonValue = true,
                Name = "Editar",
                Width = 60
            });

            grid.Columns.Add(new DataGridViewButtonColumn
            {
                HeaderText = "Excluir",
                Text = "Excluir",
                UseColumnTextForButtonValue = true,
                Name = "Excluir",
                Width = 60
            });

            grid.CellClick += Grid_CellClick;
            var painelGrid = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(1),
                BorderStyle = BorderStyle.None,
                BackColor = CoresApp.FundoPrincipal
            };

            painelGrid.Controls.Add(grid);

            // Painel do topo com botão de exportar
            var panelTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
              
               BackColor = CoresApp.FundoTopo

            };

            btnExportar = new BotaoCustomizado
            {
                Text = "Exportar CSV",
                Width = 120,
                Height = 30,
                BorderRadius = 6,
                LightBackColor = Color.FromArgb(0, 255, 156),
                LightHoverColor = Color.FromArgb(0, 230, 140)
            };
            btnExportar.Click += BtnExportar_Click;

            EstiloHelper.AplicarEstiloBotao(btnExportar);
            panelTop.Controls.Add(btnExportar);

            Controls.Add(painelGrid);
            Controls.Add(panelTop);
        }

        private void CarregarDados()
        {
            grid.Rows.Clear();
            var movimentos = DatabaseHelper.ObterTodos();

            foreach (var (id, mov) in movimentos)
            {
                grid.Rows.Add(id, mov.Tipo, mov.Descricao, $"R$ {mov.Valor:F2}");
            }
        }

        private void BtnExportar_Click(object sender, EventArgs e)
        {
            SaveFileDialog salvar = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                FileName = "orcamento.csv",
                Title = "Salvar como"
            };

            if (salvar.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    var linhas = new List<string> { "Id,Tipo,Descrição,Valor" };
                    var movimentos = DatabaseHelper.ObterTodos();

                    foreach (var (id, mov) in movimentos)
                    {
                        linhas.Add($"{id},{mov.Tipo},{mov.Descricao},\"{mov.Valor}\"");
                    }

                    System.IO.File.WriteAllLines(salvar.FileName, linhas);
                    DialogMensagem.Mostrar("Sucesso", "Arquivo exportado com sucesso!", TipoDialogo.Sucesso);
                }
                catch (Exception ex)
                {
                    DialogMensagem.Mostrar("Erro", $"Erro ao exportar: {ex.Message}", TipoDialogo.Erro);
                }
            }
        }
        public static class CoresApp
        {
            public static Color FundoPrincipal => Color.WhiteSmoke;
            public static Color FundoTopo => Color.FromArgb(245, 245, 245);
        }

        private void Grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            string coluna = grid.Columns[e.ColumnIndex].HeaderText;
            int id = Convert.ToInt32(grid.Rows[e.RowIndex].Cells["Id"].Value);

            if (coluna == "Editar")
            {
                string tipoAtual = grid.Rows[e.RowIndex].Cells["Tipo"].Value.ToString();
                string descAtual = grid.Rows[e.RowIndex].Cells["Descricao"].Value.ToString();
                string valorAtual = grid.Rows[e.RowIndex].Cells["Valor"].Value.ToString().Replace("R$ ", "");

                string novaDescricao = Microsoft.VisualBasic.Interaction.InputBox("Nova descrição:", "Editar", descAtual);
                string novoValorStr = Microsoft.VisualBasic.Interaction.InputBox("Novo valor:", "Editar", valorAtual);

                if (decimal.TryParse(novoValorStr, out decimal novoValor))
                {
                    var novoMov = new Movimento
                    {
                        Tipo = tipoAtual,
                        Descricao = novaDescricao,
                        Valor = novoValor
                    };

                    DatabaseHelper.EditarMovimento(id, novoMov);
                    CarregarDados();
                }
                else
                {
                    DialogMensagem.MostrarValorInvalido();
                }
            }
            else if (coluna == "Excluir")
            {
                var confirm = MessageBox.Show("Deseja excluir este movimento?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirm == DialogResult.Yes)
                {
                    DatabaseHelper.RemoverMovimento(id);
                    CarregarDados();
                }
            }
        }
    }
}
