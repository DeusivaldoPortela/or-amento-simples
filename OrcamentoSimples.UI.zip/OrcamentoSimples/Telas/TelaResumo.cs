﻿using OrcamentoSimples.Helpers;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace OrcamentoSimples.Telas
{
    public partial class TelaResumo : UserControl
    {
        private Label lblReceita;
        private Label lblDespesa;
        private Label lblSaldo;


        //tela Resumo

        public TelaResumo()
        {
            InitializeComponent();
            CriarControles();
            CalcularResumo();
        }

        //criação dos controles
        private void CriarControles()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.WhiteSmoke;

            lblReceita = CriarLabelResumo("Total de Receitas: R$ 0,00", new Point(40, 40), Color.FromArgb(0, 200, 120));
            lblDespesa = CriarLabelResumo("Total de Despesas: R$ 0,00", new Point(40, 100), Color.FromArgb(220, 70, 70));
            lblSaldo = CriarLabelResumo("Saldo: R$ 0,00", new Point(40, 160), Color.FromArgb(0, 100, 200));

            this.Controls.AddRange(new Control[] { lblReceita, lblDespesa, lblSaldo });
        }


        //criação das labels sobre o resumo / simples apenas para compreensão
        private Label CriarLabelResumo(string texto, Point posicao, Color corTexto)
        {
            return new Label
            {
                Text = texto,
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = corTexto,
                Location = posicao,
                AutoSize = true
            };
        }


        //calcula os valores vindo do banco de dados sqlite
        private void CalcularResumo()
        {
            var todos = DatabaseHelper.ObterTodos();

            decimal totalReceita = todos
                .Where(t => t.Mov.Tipo == "Receita")
                .Sum(t => t.Mov.Valor);

            decimal totalDespesa = todos
                .Where(t => t.Mov.Tipo == "Despesa")
                .Sum(t => t.Mov.Valor);

            decimal saldo = totalReceita - totalDespesa;

            lblReceita.Text = $"Total de Receitas: R$ {totalReceita:F2}";
            lblDespesa.Text = $"Total de Despesas: R$ {totalDespesa:F2}";
            lblSaldo.Text = $"Saldo: R$ {saldo:F2}";
        }
    }
}
