﻿using OrcamentoSimples.Controles;
using OrcamentoSimples.Helpers;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace OrcamentoSimples.Telas
{
    public partial class TelaFiltros : UserControl
    {
        private DataGridPersonalizado grid;
        private ComboBox tipoBox;
        private TextBox descBox;
        private TextBox txtValorMin;
        private TextBox txtValorMax;
        private BotaoCustomizado btnFiltrar;

        public TelaFiltros()
        {
            InitializeComponent();
            CriarControles();
        }


        //criação dos controles
        private void CriarControles()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.WhiteSmoke;

            int top = 20, left = 20, espaço = 10;

            // Label Tipo
            var lblTipo = new Label
            {
                Text = "Tipo:",
                Location = new Point(left, top + 5),
                Width = 40
            };

            tipoBox = new ComboBox
            {
                Location = new Point(lblTipo.Right + espaço, top),
                Width = 100,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            tipoBox.Items.AddRange(new string[] { "", "Receita", "Despesa" });

            // Label Descrição
            var lblDesc = new Label
            {
                Text = "Descrição:",
                Location = new Point(tipoBox.Right + 2 * espaço, top + 5),
                Width = 70
            };

            descBox = new TextBox
            {
                Location = new Point(lblDesc.Right + espaço, top),
                Width = 150
            };

            // Valor Mínimo
            var lblMin = new Label
            {
                Text = "Valor mín:",
                Location = new Point(descBox.Right + 2 * espaço, top + 5),
                Width = 65
            };

            txtValorMin = new TextBox
            {
                Location = new Point(lblMin.Right + espaço, top),
                Width = 60
            };

            // Valor Máximo
            var lblMax = new Label
            {
                Text = "Valor máx:",
                Location = new Point(txtValorMin.Right + 2 * espaço, top + 5),
                Width = 70
            };

            txtValorMax = new TextBox
            {
                Location = new Point(lblMax.Right + espaço, top),
                Width = 60
            };

            // Botão filtrar
            btnFiltrar = new BotaoCustomizado
            {
                Text = "Filtrar",
                Width = 80,
                Height = 25,
                BorderRadius = 4,
                Location = new Point(txtValorMax.Right + 2 * espaço, top),
                LightBackColor = Color.FromArgb(0, 255, 156),
                LightHoverColor = Color.FromArgb(0, 230, 140)
            };
            btnFiltrar.Click += BtnFiltrar_Click;
            EstiloHelper.AplicarEstiloBotao(btnFiltrar);

            // Grid
            grid = new DataGridPersonalizado
            {
                Location = new Point(left, top + 50),
                Size = new Size(840, 400),
                ReadOnly = true
            };

            grid.Columns.Add("Tipo", "Tipo");
            grid.Columns.Add("Descricao", "Descrição");
            grid.Columns.Add("Valor", "Valor");

            // Adiciona todos os controles
            Controls.AddRange(new Control[] {
                lblTipo, tipoBox,
                lblDesc, descBox,
                lblMin, txtValorMin,
                lblMax, txtValorMax,
                btnFiltrar,
                grid
            });
        }

        //botão criado para filtrar os dados
        private void BtnFiltrar_Click(object sender, EventArgs e)
        {
            string tipo = tipoBox.SelectedItem?.ToString();
            string descricao = descBox.Text.ToLower().Trim();

            bool minOk = decimal.TryParse(txtValorMin.Text, out decimal valorMin);
            bool maxOk = decimal.TryParse(txtValorMax.Text, out decimal valorMax);

            if (!minOk) valorMin = 0;
            if (!maxOk) valorMax = decimal.MaxValue;

            var todos = DatabaseHelper.ObterTodos();

            var filtrados = todos.Where(t =>
            {
                var (id, mov) = t;
                return (string.IsNullOrEmpty(tipo) || mov.Tipo == tipo) &&
                       (string.IsNullOrWhiteSpace(descricao) || mov.Descricao.ToLower().Contains(descricao)) &&
                       (mov.Valor >= valorMin && mov.Valor <= valorMax);
            }).ToList();

            grid.Rows.Clear();

            foreach (var (_, mov) in filtrados)
            {
                grid.Rows.Add(mov.Tipo, mov.Descricao, $"R$ {mov.Valor:F2}");
            }

            if (!filtrados.Any())
            {
                DialogMensagem.Mostrar("Nenhum resultado", "Nenhum movimento encontrado com os filtros aplicados.", TipoDialogo.Informacao);
            }
        }
    }
}
