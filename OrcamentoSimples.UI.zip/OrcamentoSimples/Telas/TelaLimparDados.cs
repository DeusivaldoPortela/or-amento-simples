﻿using OrcamentoSimples.Helpers;
using OrcamentoSimples.Controles;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace OrcamentoSimples.Telas
{
    public partial class TelaLimparDados : UserControl
    {
        private Label lblAviso;
        private BotaoCustomizado btnLimpar;

        public TelaLimparDados()
        {
            InitializeComponent();
            CriarControles();
        }
        //criação dos controles
        private void CriarControles()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.WhiteSmoke;

            lblAviso = new Label
            {
                Text = "Esta ação irá apagar todos os dados do sistema.\n\nEssa ação não poderá ser desfeita.",
                Font = new Font("Segoe UI", 11F, FontStyle.Regular),
                ForeColor = Color.FromArgb(60, 60, 60),
                AutoSize = false,
                Size = new Size(500, 100),
                Location = new Point(50, 40)
            };

            btnLimpar = new BotaoCustomizado
            {
                Text = "Apagar Tudo",
                Width = 160,
                Height = 40,
                BorderRadius = 6,
                Location = new Point(50, 150),
                LightBackColor = Color.FromArgb(255, 70, 70),
                LightHoverColor = Color.FromArgb(230, 60, 60)
            };

            btnLimpar.Click += BtnLimpar_Click;
            EstiloHelper.AplicarEstiloBotao(btnLimpar);

            Controls.Add(lblAviso);
            Controls.Add(btnLimpar);
        }

        //botão para limpar os dados do banco de dados 
        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show("Tem certeza que deseja apagar todos os dados?", "Confirmação",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                try
                {
                    DatabaseHelper.LimparBanco();
                    DialogMensagem.Mostrar("Sucesso", "Todos os dados foram apagados com sucesso.", TipoDialogo.Sucesso);
                }
                catch (Exception ex)
                {
                    DialogMensagem.Mostrar("Erro ao limpar", ex.Message, TipoDialogo.Erro);
                }
            }
        }
    }
}
